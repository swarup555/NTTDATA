﻿using BE;
using BS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace NTTDATA.Controllers
{
    public class EmployeeController : ApiController
    {
        IEmployee _Employee;
        public EmployeeController()
        {
            _Employee = new EmployeeService();
        }
        public IEnumerable<Employee> Get()
        {
            var EMPDetails = _Employee.GetAllEmployee();
            return EMPDetails;
        }
        public Employee Get(int id)
        {
            var EMPDetails = _Employee.GetEmployeeById(id);
            return EMPDetails;
        }
        public bool Post([FromBody] Employee value)
        {
            bool isinsreted = _Employee.CreateEmployee(value);
            return isinsreted;
        }
        public bool Put(int id, [FromBody]Employee value)
        {
            bool isupdated = _Employee.UpdateEmployee(id,value);
            return isupdated;
        }
        public bool Delete(int id)
        {
            bool isdeleted = _Employee.DeleteEmployee(id);
            return isdeleted;
        }
    }
}
