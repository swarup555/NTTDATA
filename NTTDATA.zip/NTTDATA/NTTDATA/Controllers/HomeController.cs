﻿using BS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NTTDATA.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        IEmployee _Employee;
        public HomeController()
        {
            _Employee = new EmployeeService();
        }
        public ActionResult Index()
        {
            Log.Info("Home-page started...");
            return View();
        }
        public JsonResult geallDesignation()
        {
            var data = _Employee.GetAllDesignation();
            return Json(data, JsonRequestBehavior.AllowGet);

        }
    }
}