﻿using BE;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BS
{
    public interface IEmployee
    {
        IEnumerable<Employee> GetAllEmployee();
        IEnumerable<Designation> GetAllDesignation();
        Employee GetEmployeeById(int EmployeeId);
        bool CreateEmployee(Employee EmployeeEntities);
        bool UpdateEmployee(int EmployeeId, Employee EmployeeEntities);
        bool DeleteEmployee(int EmployeeId);
    }
}
