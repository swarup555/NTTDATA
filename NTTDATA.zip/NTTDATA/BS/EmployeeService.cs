﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;
using DAL;
using System.Data.Entity;
using log4net;

namespace BS
{
    public class EmployeeService : IEmployee
    {
        
        private EmployeeEntities _context;
        public EmployeeService()
        {
            _context = new EmployeeEntities();
        }

        public bool CreateEmployee(Employee EmployeeEntities)
        {
            bool status = false;
            try
            {
                Tbl_Employee obj = new Tbl_Employee();
                obj.Firstname = EmployeeEntities.Firstname;
                obj.Lastname = EmployeeEntities.Lastname;
                obj.Designation = EmployeeEntities.Designation;
                obj.Salary = EmployeeEntities.Salary;
                _context.Tbl_Employee.Add(obj);
                _context.SaveChanges();
                status = true;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                status = false;
            }
            return status;
        }

        public bool DeleteEmployee(int EmployeeId)
        {
            bool status = false;
            try
            {
                
                var data = _context.Tbl_Employee.Find(EmployeeId);
                if (data != null)
                {
                    _context.Tbl_Employee.Remove(data);
                    _context.SaveChanges();
                    status = true;
                }
                else
                {
                    status = false;
                }

            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                status = false;
            }
            return status;
        }

        public IEnumerable<Designation> GetAllDesignation()
        {
            try
            {
               
                var designation = (from a in _context.Tbl_Designation
                                   select new Designation
                                   {
                                       ID = a.ID,
                                       Dname = a.Dname,
                                   }).ToList();

                return designation;

            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                return null;
            }
        }

        public IEnumerable<Employee> GetAllEmployee()
        {
            try
            {
                var bsicinfo = (from a in _context.Tbl_Employee
                                join b in _context.Tbl_Designation
                                on a.Designation equals b.ID
                                select new Employee
                                {
                                    Firstname = a.Firstname,
                                    Lastname = a.Lastname,
                                    Designationname = b.Dname,
                                    Salary = a.Salary,
                                    EmpCode = a.EmpCode,
                                    Designation = a.Designation
                                }).ToList();

                return bsicinfo;

            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                return null;
            }

        }

        public Employee GetEmployeeById(int EmployeeId)
        {
            try
            {
                var bsicinfo = (from a in _context.Tbl_Employee
                                join b in _context.Tbl_Designation
                                on a.Designation equals b.ID
                                where a.EmpCode == EmployeeId
                                select new Employee
                                {
                                    Firstname = a.Firstname,
                                    Lastname = a.Lastname,
                                    Designationname = b.Dname,
                                    Salary = a.Salary,
                                    EmpCode = a.EmpCode,
                                    Designation = a.Designation
                                }).FirstOrDefault();

                return bsicinfo;

            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                return null;
            }
        }

        public bool UpdateEmployee(int EmployeeId, Employee EmployeeEntities)
        {
            bool status = false;
            try
            {
                var obj = _context.Tbl_Employee.Find(EmployeeId);
                if (obj != null)
                {
                    obj.Firstname = EmployeeEntities.Firstname;
                    obj.Lastname = EmployeeEntities.Lastname;
                    obj.Designation = EmployeeEntities.Designation;
                    obj.Salary = EmployeeEntities.Salary;
                    _context.Entry(obj).State = EntityState.Modified;
                    _context.SaveChanges();
                    status = true;
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                status = false;
            }
            return status;
        }
    }
}
