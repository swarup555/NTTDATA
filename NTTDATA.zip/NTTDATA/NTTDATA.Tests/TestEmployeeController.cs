﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using NTTDATA.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NTTDATA.Tests
{
    [TestClass]
    public class TestEmployeeController
    {
        [TestMethod]
        public void GetAllProducts_ShouldReturnAllProducts()
        {
            var controller = new EmployeeController();

            var result = controller.Get();
            Assert.IsNotNull(result);
        }
    }
}
